# FINTECH LOAN RISK ANALYSIS PROJECT
# 1. IMPORT LIBRARIES

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 2. LOAD DATASET
df = pd.read_csv("Fintech_Loan_Risk_Expert_Project.csv")
print("\nFirst 5 rows:")
print(df.head())
print("\nDataset shape:")
print(df.shape)


# TOPIC 1: OPENING AND AUDITING LOAN DATA
# TASK 1: Load Loan Data and Check Memory
print("\n" + "=" * 60)
print("TASK 1: MEMORY USAGE")
print("=" * 60)
print(df.info(memory_usage="deep"))
print("\nDetailed memory usage:")
print(df.memory_usage(deep=True))


# TASK 2: Reorder Columns
print("\n" + "=" * 60)
print("TASK 2: REORDER COLUMNS")
print("=" * 60)

first_columns = [
    "Age",
    "Annual_Income",
    "Credit_Score"
]

remaining_columns = [
    column
    for column in df.columns
    if column not in first_columns
]

df = df[first_columns + remaining_columns]

print("New column order:")
print(df.columns.tolist())

# TOPIC 2: FIXING DATA TYPES AND VALIDATING RULES
# TASK 3: Change Columns to Correct Types
print("\n" + "=" * 60)
print("TASK 3: DATA TYPES")
print("=" * 60)

df["Age"] = df["Age"].astype(int)

df["Loan_Term_Months"] = df["Loan_Term_Months"].astype(int)

df["Debt_to_Income_Ratio"] = (
    df["Debt_to_Income_Ratio"].astype(float)
)

print(df.dtypes)


# TASK 4: Check Bad or Blank Values
print("\n" + "=" * 60)
print("TASK 4: MISSING, BLANK AND INFINITE VALUES")
print("=" * 60)

# Missing values
print("\nMissing values:")
print(df.isna().sum())

# Blank values
print("\nBlank values:")
print((df == "").sum())

# Numeric columns
numeric_df = df.select_dtypes(include=np.number)

# Infinite values
print("\nInfinite values:")
print(np.isinf(numeric_df).sum())

# Overall check
has_missing = df.isna().any().any()

has_blank = (df == "").any().any()

has_infinity = np.isinf(numeric_df).any().any()

print("\nAny missing values:", has_missing)
print("Any blank values:", has_blank)
print("Any infinite values:", has_infinity)


# TASK 5: Validate Business Rules
print("\n" + "=" * 60)
print("TASK 5: BUSINESS RULE VALIDATION")
print("=" * 60)

# Annual income > 0
invalid_income = df[
    df["Annual_Income"] <= 0
]

print("\nBorrowers with invalid income:")
print(invalid_income)

# Credit score 300 - 850
invalid_credit_score = df[
    (df["Credit_Score"] < 300) |
    (df["Credit_Score"] > 850)
]

print("\nBorrowers with invalid credit score:")
print(invalid_credit_score)


# TASK 6: Loan Amount Percentiles
print("\n" + "=" * 60)
print("TASK 6: LOAN AMOUNT PERCENTILES")
print("=" * 60)

loan_percentiles = df["Loan_Amount"].quantile(
    [0.25, 0.50, 0.75, 0.90]
)

print(loan_percentiles)


# TOPIC 3: CALCULATING STATISTICS BY HAND
# TASK 7: Calculate Average Income Manually
print("\n" + "=" * 60)
print("TASK 7: MANUAL MEAN")
print("=" * 60)

income = df["Annual_Income"]

total_income = income.sum()

number_of_people = len(income)

manual_mean = (
    total_income / number_of_people
)

python_mean = income.mean()

print("Total Income:", total_income)

print("Number of People:", number_of_people)

print("Manual Mean:", manual_mean)

print("Python Mean:", python_mean)

print("Difference:", manual_mean - python_mean)



# TASK 8: Calculate Variance Manually
print("\n" + "=" * 60)
print("TASK 8: MANUAL VARIANCE")
print("=" * 60)

mean_income = (
    income.sum() / len(income)
)

# Difference from mean
differences = income - mean_income

# Square the differences
squared_differences = differences ** 2

# Sum of squared differences
sum_squared_differences = (
    squared_differences.sum()
)

# Population variance
manual_variance = (
    sum_squared_differences /
    len(income)
)

python_variance = income.var(
    ddof=0
)

print("Manual Variance:", manual_variance)

print("Python Variance:", python_variance)

print(
    "Difference:",
    manual_variance - python_variance
)


# TASK 9: Calculate Standard Deviation Manually
print("\n" + "=" * 60)
print("TASK 9: MANUAL STANDARD DEVIATION")
print("=" * 60)

manual_std = np.sqrt(
    manual_variance
)

python_std = income.std(
    ddof=0
)

print("Manual Standard Deviation:", manual_std)

print("Python Standard Deviation:", python_std)

print(
    "Difference:",
    manual_std - python_std
)


# TASK 10: Population vs Sample Standard Deviation
print("\n" + "=" * 60)
print("TASK 10: POPULATION VS SAMPLE STD")
print("=" * 60)

credit_score = df["Credit_Score"]

population_std = credit_score.std(
    ddof=0
)

sample_std = credit_score.std(
    ddof=1
)

difference = (
    sample_std - population_std
)

print("Population Standard Deviation:")
print(population_std)

print("\nSample Standard Deviation:")
print(sample_std)

print("\nDifference:")
print(difference)


# TOPIC 4: FINDING MEDIANS AND OUTLIERS
# TASK 11: Find Middle Credit Score Manually
print("\n" + "=" * 60)
print("TASK 11: MANUAL MEDIAN")
print("=" * 60)

credit_scores = sorted(
    df["Credit_Score"].tolist()
)

n = len(credit_scores)

if n % 2 == 0:

    middle1 = credit_scores[n // 2 - 1]

    middle2 = credit_scores[n // 2]

    manual_median = (middle1 + middle2) / 2

else:manual_median = credit_scores[n // 2]

python_median = (df["Credit_Score"].median())

print("Manual Median:", manual_median)

print("Python Median:", python_median)


# TASK 12: Calculate Standard Error
print("\n" + "=" * 60)
print("TASK 12: STANDARD ERROR")
print("=" * 60)

sample_std_income = (
    df["Annual_Income"].std(ddof=1)
)

number_of_records = len(df)

standard_error = (
    sample_std_income /
    np.sqrt(number_of_records)
)

print("Standard Error:", standard_error)


# TASK 13: Debt Ratio IQR and Outliers
print("\n" + "=" * 60)
print("TASK 13: DEBT RATIO OUTLIERS")
print("=" * 60)

q1 = df[
    "Debt_to_Income_Ratio"
].quantile(0.25)

q3 = df[
    "Debt_to_Income_Ratio"
].quantile(0.75)

iqr = q3 - q1

lower_limit = (
    q1 - 1.5 * iqr
)

upper_limit = (
    q3 + 1.5 * iqr
)

print("Q1:", q1)

print("Q3:", q3)

print("IQR:", iqr)

print("Lower Limit:", lower_limit)

print("Upper Limit:", upper_limit)

outliers = df[
    (df["Debt_to_Income_Ratio"] < lower_limit) |
    (df["Debt_to_Income_Ratio"] > upper_limit)
]

print("\nExtreme borrowers:")
print(outliers)


# TOPIC 5: VECTOR CALCULATIONS FOR LOAN INSTALLMENTS
# TASK 14: Extract Loan Numbers into NumPy Arrays
print("\n" + "=" * 60)
print("TASK 14: NUMPY ARRAYS")
print("=" * 60)

loan_amount = (
    df["Loan_Amount"].to_numpy()
)

interest_rate = (
    df["Interest_Rate"].to_numpy()
)

loan_term = (
    df["Loan_Term_Months"].to_numpy()
)

print("Loan Amount Array:")
print(loan_amount)

print("\nInterest Rate Array:")
print(interest_rate)

print("\nLoan Term Array:")
print(loan_term)


# TASK 15: Convert Annual Interest to Monthly
print("\n" + "=" * 60)
print("TASK 15: MONTHLY INTEREST")
print("=" * 60)

monthly_interest = (
    interest_rate / 100 / 12
)

print(monthly_interest)


# TASK 16: Calculate Monthly EMI
print("\n" + "=" * 60)
print("TASK 16: EMI CALCULATION")
print("=" * 60)

P = loan_amount

r = monthly_interest

n = loan_term

emi = np.where(
    r == 0,
    P / n,
    P * r * (1 + r) ** n /
    ((1 + r) ** n - 1)
)

df["Calculated_EMI"] = emi

print(
    df[
        [
            "Loan_Amount",
            "Interest_Rate",
            "Loan_Term_Months",
            "Calculated_EMI"
        ]
    ].head()
)


# TASK 17: Verify Calculated Payments
print("\n" + "=" * 60)
print("TASK 17: EMI VERIFICATION")
print("=" * 60)

df["EMI_Difference"] = (
    df["Calculated_EMI"] -
    df["Monthly_EMI"]
)

print(
    df[
        [
            "Monthly_EMI",
            "Calculated_EMI",
            "EMI_Difference"
        ]
    ].head()
)

print(
    "\nMaximum EMI difference:",
    df["EMI_Difference"].abs().max()
)

print(
    "\nEMI values approximately match:",
    np.allclose(
        df["Calculated_EMI"],
        df["Monthly_EMI"],
        rtol=0.01,
        atol=1
    )
)


# TOPIC 6: WORKING WITH 2D NUMBER TABLES
# TASK 18: Combine Loan Features into Matrix
print("\n" + "=" * 60)
print("TASK 18: 2D LOAN MATRIX")
print("=" * 60)

loan_matrix = np.vstack(
    [
        df["Loan_Amount"].to_numpy(),
        df["Annual_Income"].to_numpy(),
        df["Monthly_EMI"].to_numpy()
    ]
).T

print("Matrix shape:")
print(loan_matrix.shape)

print("\nFirst 5 rows:")
print(loan_matrix[:5])

column_averages = np.mean(
    loan_matrix,
    axis=0
)

print("\nAverage Loan Amount:")
print(column_averages[0])

print("\nAverage Annual Income:")
print(column_averages[1])

print("\nAverage Monthly EMI:")
print(column_averages[2])


# TASK 19: Calculate Yearly Debt Burden
print("\n" + "=" * 60)
print("TASK 19: YEARLY DEBT BURDEN")
print("=" * 60)

yearly_debt_burden = (
    loan_matrix[:, 2] * 12
) / loan_matrix[:, 1]

df["Yearly_Debt_Burden"] = (
    yearly_debt_burden
)

print(
    df[
        [
            "Monthly_EMI",
            "Annual_Income",
            "Yearly_Debt_Burden"
        ]
    ].head()
)


# TASK 20: Safest and Riskiest Borrowers
print("\n" + "=" * 60)
print("TASK 20: SAFEST AND RISKIEST")
print("=" * 60)

safest_position = np.argmin(
    yearly_debt_burden
)

riskiest_position = np.argmax(
    yearly_debt_burden
)

print(
    "Safest row position:",
    safest_position
)

print(
    "Safest Excel-style row:",
    safest_position + 1
)

print("\nSafest borrower:")
print(df.iloc[safest_position])

print(
    "\nRiskiest row position:",
    riskiest_position
)

print(
    "Riskiest Excel-style row:",
    riskiest_position + 1
)

print("\nRiskiest borrower:")
print(df.iloc[riskiest_position])


# TOPIC 7: GROUPING BORROWERS BY RISK
# TASK 21: Create Risk Levels
print("\n" + "=" * 60)
print("TASK 21: RISK CATEGORY")
print("=" * 60)


def risk_category(row):

    if (
        row["Credit_Score"] < 600
        or
        row["Debt_to_Income_Ratio"] > 0.45
    ):
        return "High Risk"

    elif row["Credit_Score"] >= 750:
        return "Low Risk"

    else:
        return "Medium Risk"


df["Risk_Category"] = df.apply(
    risk_category,
    axis=1
)

print(
    df[
        [
            "Credit_Score",
            "Debt_to_Income_Ratio",
            "Risk_Category"
        ]
    ].head()
)

print("\nRisk category counts:")
print(
    df["Risk_Category"].value_counts()
)


# TASK 22: Group Loans by Size
print("\n" + "=" * 60)
print("TASK 22: LOAN SIZE")
print("=" * 60)

df["Loan_Size"] = pd.qcut(
    df["Loan_Amount"],
    q=4,
    labels=[
        "Small",
        "Medium",
        "Large",
        "Very Large"
    ]
)

print(
    df[
        [
            "Loan_Amount",
            "Loan_Size"
        ]
    ].head()
)

print("\nLoan size counts:")
print(
    df["Loan_Size"].value_counts()
)


# TASK 23: Default Count by Risk Category
print("\n" + "=" * 60)
print("TASK 23: DEFAULT COUNT BY RISK")
print("=" * 60)

print("\nLoan Status values:")
print(
    df["Loan_Status"].value_counts()
)

default_table = pd.crosstab(
    df["Risk_Category"],
    df["Loan_Status"]
)

print("\nDefault table:")
print(default_table)

# TASK 24: Default Percentage by Loan Purpose
print("\n" + "=" * 60)
print("TASK 24: DEFAULT % BY PURPOSE")
print("=" * 60)

default_percentage = (
    df.groupby("Loan_Purpose")["Loan_Status"]
    .apply(
        lambda x:
        (x == "Default").mean() * 100
    )
)

print(default_percentage)


# TOPIC 8: ISOLATING BAD LOANS AND RISK EXPOSURE
# TASK 25: Filter High-Risk Defaulters
print("\n" + "=" * 60)
print("TASK 25: HIGH-RISK DEFAULTERS")
print("=" * 60)

high_risk_defaulters = df[
    (df["Risk_Category"] == "High Risk")
    &
    (df["Loan_Status"] == "Default")
]

print(
    high_risk_defaulters
)


# TASK 26: Total Active Loan Exposure
print("\n" + "=" * 60)
print("TASK 26: ACTIVE LOAN EXPOSURE")
print("=" * 60)

# Check available status values first
print(
    "Loan Status values:"
)
print(
    df["Loan_Status"].value_counts()
)

# Select Active loans
active_loans = df[
    df["Loan_Status"] == "Active"
].copy()

# Sort highest interest to lowest
active_loans = active_loans.sort_values(
    by="Interest_Rate",
    ascending=False
)

# Running loan amount
active_loans[
    "Running_Loan_Amount"
] = active_loans[
    "Loan_Amount"
].cumsum()

print(
    active_loans[
        [
            "Interest_Rate",
            "Loan_Amount",
            "Running_Loan_Amount"
        ]
    ]
)

print(
    "\nTotal Active Loan Exposure:"
)

print(
    active_loans["Loan_Amount"].sum()
)


# TASK 27: Renters vs Owners
print("\n" + "=" * 60)
print("TASK 27: RENTERS VS OWNERS")
print("=" * 60)

print("\nHome ownership values:")

print(
    df["Home_Ownership"].value_counts()
)

home_default_rates = (
    df.groupby(
        "Home_Ownership"
    )["Loan_Status"]
    .apply(
        lambda x:
        (x == "Default").mean() * 100
    )
)

print(
    "\nDefault rate by home ownership:"
)

print(home_default_rates)


# TOPIC 9: EXECUTIVE CHARTS AND DASHBOARD
# TASK 28: Correlation Heatmap
print("\n" + "=" * 60)
print("TASK 28: CORRELATION HEATMAP")
print("=" * 60)

correlation_columns = [
    "Annual_Income",
    "Credit_Score",
    "Loan_Amount",
    "Monthly_EMI"
]

correlation = df[
    correlation_columns
].corr()

plt.figure(
    figsize=(8, 6)
)

sns.heatmap(
    correlation,
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title(
    "Correlation Between Loan Features"
)

plt.tight_layout()

plt.show()


# TASK 29: Credit Score Histogram
print("\n" + "=" * 60)
print("TASK 29: CREDIT SCORE HISTOGRAM")
print("=" * 60)

mean_credit = (
    df["Credit_Score"].mean()
)

median_credit = (
    df["Credit_Score"].median()
)

plt.figure(
    figsize=(8, 5)
)

plt.hist(
    df["Credit_Score"],
    bins=20,
    edgecolor="black"
)

plt.axvline(
    mean_credit,
    linestyle="--",
    label="Mean"
)

plt.axvline(
    median_credit,
    linestyle="-",
    label="Median"
)

plt.xlabel(
    "Credit Score"
)

plt.ylabel(
    "Number of Borrowers"
)

plt.title(
    "Distribution of Credit Scores"
)

plt.legend()

plt.tight_layout()

plt.show()


# TASK 30: Interest Rates Across Risk Levels
print("\n" + "=" * 60)
print("TASK 30: INTEREST RATE BY RISK")
print("=" * 60)

plt.figure(
    figsize=(8, 5)
)

sns.boxplot(
    data=df,
    x="Risk_Category",
    y="Interest_Rate"
)

plt.xlabel(
    "Risk Category"
)

plt.ylabel(
    "Interest Rate"
)

plt.title(
    "Interest Rates Across Risk Levels"
)

plt.tight_layout()

plt.show()


# TASK 31: Income vs Loan Amount
print("\n" + "=" * 60)
print("TASK 31: INCOME VS LOAN AMOUNT")
print("=" * 60)

plt.figure(
    figsize=(8, 5)
)

sns.scatterplot(
    data=df,
    x="Annual_Income",
    y="Loan_Amount",
    hue="Loan_Status"
)

plt.xlabel(
    "Annual Income"
)

plt.ylabel(
    "Loan Amount"
)

plt.title(
    "Income vs Loan Amount"
)

plt.tight_layout()

plt.show()


# TASK 32: Debt Ratio Density Curves
print("\n" + "=" * 60)
print("TASK 32: DEBT RATIO DENSITY")
print("=" * 60)

plt.figure(
    figsize=(8, 5)
)

sns.kdeplot(
    data=df[
        df["Loan_Status"] == "Default"
    ],
    x="Debt_to_Income_Ratio",
    label="Default",
    fill=True
)

sns.kdeplot(
    data=df[
        df["Loan_Status"] == "Fully Paid"
    ],
    x="Debt_to_Income_Ratio",
    label="Fully Paid",
    fill=True
)

plt.xlabel(
    "Debt-to-Income Ratio"
)

plt.ylabel(
    "Density"
)

plt.title(
    "Debt Ratio Distribution"
)

plt.legend()

plt.tight_layout()

plt.show()


# TASK 33: Horizontal Bar Chart of Losses
print("\n" + "=" * 60)
print("TASK 33: LOSSES BY LOAN PURPOSE")
print("=" * 60)

# Unpaid amount
df["Unpaid_Loan_Amount"] = np.where(
    df["Loan_Status"] == "Default",
    df["Loan_Amount"],
    0
)

average_unpaid = (
    df.groupby(
        "Loan_Purpose"
    )["Unpaid_Loan_Amount"]
    .mean()
    .sort_values()
)

print(
    "Average unpaid loan amount:"
)

print(average_unpaid)

plt.figure(
    figsize=(8, 6)
)

average_unpaid.plot(
    kind="barh"
)

plt.xlabel(
    "Average Unpaid Loan Amount"
)

plt.ylabel(
    "Loan Purpose"
)

plt.title(
    "Average Unpaid Loan Amount by Purpose"
)

plt.tight_layout()

plt.show()


# TASK 34: 4-Chart Risk Dashboard
print("\n" + "=" * 60)
print("TASK 34: RISK DASHBOARD")
print("=" * 60)

fig, axes = plt.subplots(
    2,
    2,
    figsize=(14, 10)
)


# Chart 1: Credit Score Histogram
axes[0, 0].hist(
    df["Credit_Score"],
    bins=20,
    edgecolor="black"
)

axes[0, 0].set_title(
    "Credit Score Distribution"
)

axes[0, 0].set_xlabel(
    "Credit Score"
)

axes[0, 0].set_ylabel(
    "Borrowers"
)


# Chart 2: Debt Ratio Boxplot
sns.boxplot(
    data=df,
    y="Debt_to_Income_Ratio",
    ax=axes[0, 1]
)

axes[0, 1].set_title(
    "Debt Ratio Boxplot"
)

axes[0, 1].set_ylabel(
    "Debt-to-Income Ratio"
)


# Chart 3: Risk Category Pie Chart
risk_counts = (
    df["Risk_Category"].value_counts()
)

axes[1, 0].pie(
    risk_counts,
    labels=risk_counts.index,
    autopct="%1.1f%%"
)

axes[1, 0].set_title(
    "Risk Category Distribution"
)


# Chart 4: Income vs Loan Scatter
sns.scatterplot(
    data=df,
    x="Annual_Income",
    y="Loan_Amount",
    hue="Loan_Status",
    ax=axes[1, 1]
)

axes[1, 1].set_title(
    "Income vs Loan Amount"
)

axes[1, 1].set_xlabel(
    "Annual Income"
)

axes[1, 1].set_ylabel(
    "Loan Amount"
)


# Dashboard title
fig.suptitle(
    "FINTECH LOAN RISK DASHBOARD",
    fontsize=18
)

plt.tight_layout()

plt.show()


# TASK 35: SAVE CLEAN DATA AND FINAL SUMMARY
print("\n" + "=" * 60)
print("TASK 35: SAVE FINAL DATA")
print("=" * 60)


# Save CSV
df.to_csv(
    "Fintech_Loan_Risk_Final.csv",
    index=False
)


# Save Excel
df.to_excel(
    "Fintech_Loan_Risk_Final.xlsx",
    index=False
)


print(
    "CSV file saved as:"
)

print(
    "Fintech_Loan_Risk_Final.csv"
)

print(
    "\nExcel file saved as:"
)

print(
    "Fintech_Loan_Risk_Final.xlsx"
)


# FINAL KEY FINDINGS
print("\n" + "=" * 60)
print("FINAL KEY FINDINGS")
print("=" * 60)


# Finding 1:
# Loan purpose with highest default rate
purpose_default_rates = (
    df.groupby(
        "Loan_Purpose"
    )["Loan_Status"]
    .apply(
        lambda x:
        (x == "Default").mean() * 100
    )
)

highest_default_purpose = (
    purpose_default_rates.idxmax()
)

highest_default_rate = (
    purpose_default_rates.max()
)


print(
    f"\n1. Highest default rate is for "
    f"{highest_default_purpose}: "
    f"{highest_default_rate:.2f}%"
)


# Finding 2:
# Default rate by risk category
risk_default_rates = (
    df.groupby(
        "Risk_Category"
    )["Loan_Status"]
    .apply(
        lambda x:
        (x == "Default").mean() * 100
    )
)

print(
    "\n2. Default rate by risk category:"
)

print(
    risk_default_rates
)


# Finding 3:
# Average debt-to-income ratio
average_debt_ratio = (
    df["Debt_to_Income_Ratio"].mean()
)

print(
    f"\n3. Average Debt-to-Income Ratio: "
    f"{average_debt_ratio:.2f}"
)


# FINAL DATASET INFORMATION
print("\n" + "=" * 60)
print("FINAL DATASET INFORMATION")
print("=" * 60)

print(
    "\nFinal dataset shape:"
)

print(
    df.shape
)

print(
    "\nFinal columns:"
)

print(
    df.columns.tolist()
)

print(
    "\nFirst 5 rows of final dataset:"
)

print(
    df.head()
)

print(
    "\nPROJECT COMPLETED SUCCESSFULLY!"
)