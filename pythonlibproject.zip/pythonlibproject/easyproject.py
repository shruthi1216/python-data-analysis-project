import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns



# Task 2: Load the CSV File
df_csv = pd.read_csv("Retail_Sales_Easy_Project.csv")

print("Task 2: First 5 rows of CSV file")
print(df_csv.head())


# Task 3: Load the Excel File
df_excel = pd.read_excel(
    "Retail_Sales_Easy_Project.xlsx",
    sheet_name="SalesData"
)

print("\nTask 3: Last 5 rows of Excel file")
print(df_excel.tail())


# Task 4: View Random Rows
print("\nTask 4: 6 Random Rows")
print(df_csv.sample(6))

# Task 5: Check Data Types and Missing Values
print("\nTask 5: Column Names")
print(df_csv.columns)

print("\nData Types")
print(df_csv.dtypes)

print("\nMissing Values")
print(df_csv.isnull().sum())

# Task 6: Summary of Numerical Columns
print("\nTask 6: Statistical Summary")
print(df_csv.describe())

# Task 7: Check Table Size
print("\nTask 7: Table Size")

rows, columns = df_csv.shape

print("Total Rows:", rows)
print("Total Columns:", columns)

# Task 8: Count Non-Empty Values
print("\nTask 8: Non-Empty Values")
print(df_csv.count())


# Load CSV file
df = pd.read_csv("Retail_Sales_Easy_Project.csv")


# Task 9: Convert Revenue to Array
revenue_array = df["Total_Revenue"].to_numpy()

print("\nTask 9: Revenue Array")
print(revenue_array)
print("Data Type:", revenue_array.dtype)
print("Total Length:", len(revenue_array))


# Task 10: Create 2D Array
sales_array = df[["Unit_Price", "Quantity"]].to_numpy()

print("\nTask 10: 2D Array")
print(sales_array)
print("Shape:", sales_array.shape)


# Task 11: Grand Total Revenue
grand_total = np.sum(revenue_array)

print("\nTask 11: Grand Total Revenue")
print(grand_total)



# Task 12: Mean and Median
mean_revenue = np.mean(revenue_array)
median_revenue = np.median(revenue_array)

print("\nTask 12: Mean and Median")
print("Mean Revenue:", mean_revenue)
print("Median Revenue:", median_revenue)


# Task 13: Standard Deviation & Variance
standard_deviation = np.std(revenue_array)
variance = np.var(revenue_array)

print("\nTask 13: Spread")
print("Standard Deviation:", standard_deviation)
print("Variance:", variance)



# Task 14: Lowest and Highest Sale
lowest_revenue = np.min(revenue_array)
highest_revenue = np.max(revenue_array)

print("\nTask 14: Lowest and Highest Revenue")
print("Lowest Revenue:", lowest_revenue)
print("Highest Revenue:", highest_revenue)



# Task 15: Best and Worst Sale
best_sale_index = np.argmax(revenue_array)
worst_sale_index = np.argmin(revenue_array)

print("\nTask 15: Best and Worst Sale")
print("Index of Best Sale:", best_sale_index)
print("Index of Worst Sale:", worst_sale_index)

print("\nBest Sale:")
print(df.iloc[best_sale_index])

print("\nWorst Sale:")
print(df.iloc[worst_sale_index])



# Task 16: Running Total
running_total = np.cumsum(revenue_array)

print("\nTask 16: Running Total")
print(running_total)

# Add running total to DataFrame
df["Running_Total"] = running_total

print("\nFirst 5 rows with Running Total:")
print(df.head())


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("Retail_Sales_Easy_Project.csv")



# Topic 5: Selecting and Slicing Rows
# Task 17
print("\nTask 17: First 10 Rows")
print(df.iloc[:10])


# Task 18
print("\nTask 18: Rows 100 to 120")
print(
    df.loc[
        100:120,
        ["Product_Name", "Total_Revenue", "Store_City"]
    ]
)


# Topic 6: Filtering Records
# Task 19
print("\nTask 19: Electronics Sales")
electronics = df[df["Category"] == "Electronics"]
print(electronics)


# Task 20
print("\nTask 20: Quantity >= 5 AND UPI")
result = df[
    (df["Quantity"] >= 5) &
    (df["Payment_Method"] == "UPI")
]
print(result)


# Task 21
print("\nTask 21: Selected Cities")
cities = df[
    df["Store_City"].isin(
        ["Chennai", "Coimbatore", "Madurai"]
    )
]
print(cities)


# Task 22
print("\nTask 22: Outside Chennai")
outside_chennai = df[
    df["Store_City"] != "Chennai"
]
print(outside_chennai)


# Task 23
print("\nTask 23: High Value Orders")

df["Order_Value_Tag"] = np.where(
    df["Total_Revenue"] > 5000,
    "High Value",
    "Standard"
)

print(
    df[
        ["Total_Revenue", "Order_Value_Tag"]
    ].head()
)



# Topic 7: Creating New Columns and Sorting
# Task 24
df["Net_Profit"] = (
    df["Total_Revenue"] - df["Cost_Price"]
)

print("\nTask 24: Net Profit")
print(
    df[
        ["Total_Revenue", "Cost_Price", "Net_Profit"]
    ].head()
)


# Task 25
df["Profit_Margin_Pct"] = (
    df["Net_Profit"] /
    df["Total_Revenue"]
) * 100

print("\nTask 25: Profit Margin")
print(
    df[
        ["Net_Profit", "Profit_Margin_Pct"]
    ].head()
)


# Task 26
df_sorted_revenue = df.sort_values(
    by="Total_Revenue",
    ascending=False
)

print("\nTask 26: Revenue Sorted")
print(df_sorted_revenue)


# Task 27
df_sorted = df.sort_values(
    by=["Category", "Net_Profit"],
    ascending=[True, False]
)

print("\nTask 27: Category and Profit Sorted")
print(df_sorted)



# Topic 8: Counting and Grouping
# Task 28
print("\nTask 28: Unique Items")

print(
    "Unique Categories:",
    df["Category"].nunique()
)

print(
    "Unique Product Names:",
    df["Product_Name"].nunique()
)


# Task 29
category_sales = df.groupby("Category").agg(
    Total_Revenue=("Total_Revenue", "sum"),
    Average_Revenue=("Total_Revenue", "mean"),
    Number_of_Sales=("Total_Revenue", "count")
)

print("\nTask 29: Sales by Category")
print(category_sales)


# Topic 9: Charts
# Convert Date column
df["Date"] = pd.to_datetime(df["Date"])


# Task 30 & 31
daily_sales = df.groupby(
    "Date"
)["Total_Revenue"].sum()

plt.figure(figsize=(10, 5))

plt.plot(
    daily_sales.index,
    daily_sales.values,
    marker="o"
)

plt.xlabel("Date")
plt.ylabel("Revenue in INR")
plt.title("Sales Revenue Trend Over Time")

plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Task 32
city_sales = df.groupby(
    "Store_City"
)["Total_Revenue"].sum()

plt.figure(figsize=(8, 5))

plt.bar(
    city_sales.index,
    city_sales.values
)

plt.xlabel("Store City")
plt.ylabel("Total Revenue in INR")
plt.title("Total Sales Revenue by City")

plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Task 33
category_revenue = df.groupby(
    "Category"
)["Total_Revenue"].sum()

largest_index = category_revenue.argmax()

explode = [0] * len(category_revenue)
explode[largest_index] = 0.1

plt.figure(figsize=(7, 7))

plt.pie(
    category_revenue.values,
    labels=category_revenue.index,
    autopct="%1.1f%%",
    explode=explode
)

plt.title("Percentage Share of Sales by Category")

plt.show()


# Task 34
plt.figure(figsize=(9, 6))

sns.scatterplot(
    data=df,
    x="Unit_Price",
    y="Quantity",
    hue="Category"
)

plt.xlabel("Unit Price")
plt.ylabel("Quantity")
plt.title("Unit Price vs Quantity")

plt.show()


# Task 35
payment_profit = df.groupby(
    "Payment_Method"
)["Net_Profit"].mean()

plt.figure(figsize=(8, 5))

plt.bar(
    payment_profit.index,
    payment_profit.values
)

plt.xlabel("Payment Method")
plt.ylabel("Average Net Profit")
plt.title("Average Net Profit by Payment Method")

plt.xticks(rotation=45)
plt.tight_layout()

plt.savefig(
    "average_profit_by_payment_method.png"
)

plt.show()