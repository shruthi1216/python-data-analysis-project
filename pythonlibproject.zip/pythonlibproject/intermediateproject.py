import pandas as pd

file = "Ecommerce_Analytics_Intermediate_Project.xlsx"

# Task 1
excel_file = pd.ExcelFile(file)
print("Sheets:", excel_file.sheet_names)

# Task 2
df_orders = pd.read_excel(file, sheet_name="Raw_Orders")
print("Orders shape:", df_orders.shape)

# Task 3
df_customers = pd.read_excel(file, sheet_name="Customers")
df_products = pd.read_excel(file, sheet_name="Products")

# Task 4
df_merged = pd.merge(
    df_orders,
    df_customers,
    on="Customer_ID",
    how="left"
)

# Task 5
df_merged = pd.merge(
    df_merged,
    df_products,
    on="Product_ID",
    how="left"
)

# Task 6
print("Original rows:", len(df_orders))
print("Merged rows:", len(df_merged))

# Task 7
print("Missing customer names:",df_merged["Customer_Name"].isna().sum())

print("Missing product names:",df_merged["Product_Name"].isna().sum())


# Task 8
df_merged["Order_Date"] = pd.to_datetime(df_merged["Order_Date"])
df_merged["Delivery_Date"] = pd.to_datetime(df_merged["Delivery_Date"])


# Task 9
df_merged["Order_Year"] = df_merged["Order_Date"].dt.year
df_merged["Order_Month_Number"] = df_merged["Order_Date"].dt.month
df_merged["Order_Month_Name"] = df_merged["Order_Date"].dt.month_name()


# Task 10
df_merged["Order_Day_Name"] = df_merged["Order_Date"].dt.day_name()

print(df_merged["Order_Day_Name"].value_counts())


# Task 11
df_merged["Delivery_Days"] = (
    df_merged["Delivery_Date"] - df_merged["Order_Date"]
).dt.days


# Task 12
cancelled_orders = df_merged[
    df_merged["Delivery_Date"].isna()
]

print("Cancelled orders:", len(cancelled_orders))


# Task 13
delivered_orders = df_merged[
    df_merged["Delivery_Date"].notna()
]

average_delivery_days = delivered_orders["Delivery_Days"].mean()

print("Average Delivery Days:", average_delivery_days)


# Task 14
delivery_by_membership = (
    df_merged
    .groupby("Membership_Tier", as_index=False)["Delivery_Days"]
    .mean()
)

print(delivery_by_membership)


# Task 15
q1_orders = df_merged[
    df_merged["Order_Month_Number"].isin([1, 2, 3])
]

print(q1_orders)

# Excel file
file = "Ecommerce_Analytics_Intermediate_Project.xlsx"

# TASK 5: Add Product Details
df_merged = pd.merge(
    df_merged,
    df_products,
    on="Product_ID",
    how="left"
)

print("Task 5 - Merged Orders + Customers + Products")
print(df_merged.head())



# TASK 6: Check Merged Table Rows
print("\nTask 6 - Row Count")

print("Original Orders Rows:", len(df_orders))
print("Merged Table Rows:", len(df_merged))

if len(df_orders) == len(df_merged):
    print("No order rows were lost.")
else:
    print("Row count has changed.")



# TASK 7: Find Missing Information
print("\nTask 7 - Missing Information")

# Missing customer details
missing_customer = df_merged["Customer_Name"].isna().sum()

# Missing product details
missing_product = df_merged["Product_Name"].isna().sum()

print("Missing Customer Details:", missing_customer)
print("Missing Product Information:", missing_product)



# TASK 8: Convert Columns to Dates
df_merged["Order_Date"] = pd.to_datetime(
    df_merged["Order_Date"]
)

df_merged["Delivery_Date"] = pd.to_datetime(
    df_merged["Delivery_Date"]
)

print("\nTask 8 - Date Data Types")

print(df_merged[["Order_Date", "Delivery_Date"]].dtypes)